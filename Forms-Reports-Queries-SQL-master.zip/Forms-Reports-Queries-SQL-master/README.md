# Forms-Reports-Queries-SQL
A program using Java Swing and JFrame to create reports, forms, and perform queries using SQL. The program connects to an existing database, populates it with data, and then performs operations based on the data.
